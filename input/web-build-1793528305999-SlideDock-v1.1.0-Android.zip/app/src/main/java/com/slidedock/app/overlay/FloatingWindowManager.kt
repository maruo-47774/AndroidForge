package com.slidedock.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.*
import com.slidedock.app.model.DockPreferences
import com.slidedock.app.model.FloatingWindowModel
import com.slidedock.app.model.ToolType

/**
 * Android WindowManager を使用した複数のフローティングウィンドウ独立管理クラス
 *
 * 【改善点】
 * 1. タイトルバードラッグによる確実な指追従移動（DragStartでWindowを再破棄しない設計）
 * 2. 画面外への完全離脱防止クランプ（タイトルバーと本体が常に操作可能な領域に留まる）
 * 3. ウィンドウタップ時またはドラッグ終了時のスムーズな最前面化 (bringToFront)
 * 4. 最小化・最大化・復元・リサイズ・閉じる操作と独立状態の SharedPreferences 永続化
 */
class FloatingWindowManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val viewModelStoreOwner: ViewModelStoreOwner,
    private val savedStateRegistryOwner: SavedStateRegistryOwner
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val activeWindows = LinkedHashMap<String, WindowViewHolder>()

    data class WindowViewHolder(
        val model: FloatingWindowModel,
        val rootView: FrameLayout,
        val layoutParams: WindowManager.LayoutParams
    )

    private fun getScreenWidth(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.widthPixels
    }

    private fun getScreenHeight(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.heightPixels
    }

    private fun dpToPx(dp: Int): Int {
        val density = context.resources.displayMetrics.density
        return (dp * density).toInt()
    }

    /**
     * ツールに対応する独立フローティングウィンドウを開く
     */
    fun openToolWindow(toolType: ToolType) {
        val existing = activeWindows.values.find { it.model.toolType == toolType }
        if (existing != null) {
            if (existing.model.isMinimized) {
                restoreWindow(existing.model.id)
            } else {
                bringToFront(existing.model.id)
            }
            return
        }

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()
        val defaultW = Math.min(screenW - dpToPx(32), dpToPx(toolType.defaultWidthDp))
        val defaultH = Math.min(screenH - dpToPx(64), dpToPx(toolType.defaultHeightDp))

        // 重複配置を避けるオフセット計算
        val offset = (activeWindows.size % 5) * dpToPx(28)
        val initialX = Math.max(dpToPx(16), Math.min(screenW - defaultW - dpToPx(16), dpToPx(36) + offset))
        val initialY = Math.max(dpToPx(36), Math.min(screenH - defaultH - dpToPx(36), dpToPx(50) + offset))

        val model = FloatingWindowModel(
            id = "win_${toolType.name}_${System.currentTimeMillis()}",
            toolType = toolType,
            x = initialX,
            y = initialY,
            width = defaultW,
            height = defaultH
        )

        createAndAddWindow(model)
        saveState()
    }

    fun restoreSavedWindows() {
        val saved = DockPreferences.getWindows(context)
        for (model in saved) {
            if (!model.isMinimized) {
                createAndAddWindow(model)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createAndAddWindow(model: FloatingWindowModel) {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            model.width,
            model.height,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = model.x
            y = model.y
        }

        val rootView = FrameLayout(context).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowManager.lifecycleOwner)
            setViewTreeViewModelStoreOwner(this@FloatingWindowManager.viewModelStoreOwner)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowManager.savedStateRegistryOwner)
        }

        val composeView = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowManager.lifecycleOwner)
            setViewTreeViewModelStoreOwner(this@FloatingWindowManager.viewModelStoreOwner)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowManager.savedStateRegistryOwner)
            setContent {
                FloatingWindowView(
                    model = model,
                    onMinimize = { minimizeWindow(model.id) },
                    onToggleMaximize = { toggleMaximizeWindow(model.id) },
                    onClose = { closeWindow(model.id) },
                    onDragMove = { deltaX, deltaY ->
                        moveWindow(model.id, deltaX.toInt(), deltaY.toInt())
                    },
                    onDragEnd = {
                        saveState()
                        bringToFront(model.id)
                    },
                    onResizeMove = { deltaW, deltaH ->
                        resizeWindow(model.id, deltaW.toInt(), deltaH.toInt())
                    },
                    onResizeEnd = { saveState() }
                )
            }
        }

        rootView.addView(composeView)

        // タップ完了時に最前面へ移動（ACTION_DOWN で破棄するとドラッグがキャンセルされるため ACTION_UP で実行）
        rootView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val lastId = activeWindows.keys.lastOrNull()
                if (lastId != model.id) {
                    bringToFront(model.id)
                }
            }
            false
        }

        try {
            windowManager.addView(rootView, params)
            activeWindows[model.id] = WindowViewHolder(model, rootView, params)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * タイトルバードラッグによる指追従移動＆画面外逸脱防止クランプ
     */
    fun moveWindow(id: String, deltaX: Int, deltaY: Int) {
        val holder = activeWindows[id] ?: return
        if (holder.model.isMaximized) return

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        var newX = holder.layoutParams.x + deltaX
        var newY = holder.layoutParams.y + deltaY

        // 画面外への完全離脱防止クランプ
        // 左右に少なくとも 60dp、タイトルバー(38dp)が画面上端〜下端に収まるように制限
        val minVisibleX = dpToPx(60)
        val minVisibleY = dpToPx(38)
        newX = Math.max(-holder.layoutParams.width + minVisibleX, Math.min(screenW - minVisibleX, newX))
        newY = Math.max(0, Math.min(screenH - minVisibleY, newY))

        holder.layoutParams.x = newX
        holder.layoutParams.y = newY
        holder.model.x = newX
        holder.model.y = newY

        try {
            windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * 右下グリップによるウィンドウサイズ変更
     */
    fun resizeWindow(id: String, deltaW: Int, deltaH: Int) {
        val holder = activeWindows[id] ?: return
        if (holder.model.isMaximized) return

        val minW = dpToPx(180)
        val minH = dpToPx(140)
        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        var newW = holder.layoutParams.width + deltaW
        var newH = holder.layoutParams.height + deltaH

        newW = Math.max(minW, Math.min(screenW - holder.layoutParams.x, newW))
        newH = Math.max(minH, Math.min(screenH - holder.layoutParams.y, newH))

        holder.layoutParams.width = newW
        holder.layoutParams.height = newH
        holder.model.width = newW
        holder.model.height = newH

        try {
            windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun toggleMaximizeWindow(id: String) {
        val holder = activeWindows[id] ?: return
        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        if (holder.model.isMaximized) {
            // 復元
            holder.model.isMaximized = false
            holder.layoutParams.x = holder.model.prevX
            holder.layoutParams.y = holder.model.prevY
            holder.layoutParams.width = holder.model.prevWidth
            holder.layoutParams.height = holder.model.prevHeight
        } else {
            // 最大化（元の座標・サイズを保存）
            holder.model.isMaximized = true
            holder.model.prevX = holder.layoutParams.x
            holder.model.prevY = holder.layoutParams.y
            holder.model.prevWidth = holder.layoutParams.width
            holder.model.prevHeight = holder.layoutParams.height

            holder.layoutParams.x = dpToPx(8)
            holder.layoutParams.y = dpToPx(8)
            holder.layoutParams.width = screenW - dpToPx(16)
            holder.layoutParams.height = screenH - dpToPx(16)
        }

        try {
            windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    fun minimizeWindow(id: String) {
        val holder = activeWindows[id] ?: return
        holder.model.isMinimized = true
        try {
            windowManager.removeView(holder.rootView)
        } catch (e: Exception) {
            // ignore
        }
        activeWindows.remove(id)
        saveState()
    }

    fun restoreWindow(id: String) {
        val saved = DockPreferences.getWindows(context)
        val model = saved.find { it.id == id } ?: return
        model.isMinimized = false
        createAndAddWindow(model)
        saveState()
    }

    fun closeWindow(id: String) {
        val holder = activeWindows.remove(id) ?: return
        try {
            windowManager.removeView(holder.rootView)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    /**
     * 指定されたウィンドウを最前面に表示する（不要な破棄・再生成を防止）
     */
    fun bringToFront(id: String) {
        val holder = activeWindows[id] ?: return
        val lastId = activeWindows.keys.lastOrNull()
        if (lastId == id) return // すでに最前面

        try {
            windowManager.removeView(holder.rootView)
            windowManager.addView(holder.rootView, holder.layoutParams)
            activeWindows.remove(id)
            activeWindows[id] = holder
        } catch (e: Exception) {
            // ignore
        }
    }

    fun getActiveWindowsCount(): Int = activeWindows.size

    private fun saveState() {
        val list = activeWindows.values.map { it.model }
        DockPreferences.saveWindows(context, list)
    }

    fun destroy() {
        for (holder in activeWindows.values) {
            try {
                windowManager.removeView(holder.rootView)
            } catch (e: Exception) {
                // ignore
            }
        }
        activeWindows.clear()
    }
}