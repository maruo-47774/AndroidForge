package com.slidedock.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.slidedock.app.model.DockPosition
import com.slidedock.app.model.DockPreferences
import com.slidedock.app.model.ToolType
import com.slidedock.app.service.OverlayService
import com.slidedock.app.ui.theme.SlideDockTheme

/**
 * SlideDock メイン画面 (v1.1.0)
 * - マルチウィンドウ＆ハンドルドラッグ対応
 * - SYSTEM_ALERT_WINDOW 権限の判定と設定画面誘導
 * - オーバーレイサービスの起動・停止
 * - ハンドルの左右配置選択およびツール直接テスト
 */
class MainActivity : ComponentActivity() {

    private var isServiceRunning by mutableStateOf(false)

    private val serviceStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == OverlayService.ACTION_STATE_CHANGED) {
                isServiceRunning = intent.getBooleanExtra(OverlayService.EXTRA_IS_RUNNING, false)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isServiceRunning = OverlayService.isRunning

        val filter = IntentFilter(OverlayService.ACTION_STATE_CHANGED)
        ContextCompat.registerReceiver(
            this,
            serviceStateReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        setContent {
            SlideDockTheme(darkTheme = true) {
                MainScreen(
                    isServiceRunning = isServiceRunning,
                    onStartService = { startOverlayService() },
                    onStopService = { stopOverlayService() },
                    onUpdatePosition = { position -> updateDockPosition(position) },
                    onLaunchTool = { tool -> launchToolWindow(tool) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isServiceRunning = OverlayService.isRunning
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(serviceStateReceiver)
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        isServiceRunning = true
    }

    private fun stopOverlayService() {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_STOP
        }
        startService(intent)
        isServiceRunning = false
    }

    private fun updateDockPosition(position: DockPosition) {
        DockPreferences.savePosition(this, position)
        if (isServiceRunning) {
            val intent = Intent(this, OverlayService::class.java).apply {
                action = OverlayService.ACTION_UPDATE_POSITION
                putExtra(OverlayService.EXTRA_POSITION, position.name)
            }
            startService(intent)
        }
    }

    private fun launchToolWindow(tool: ToolType) {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        if (!isServiceRunning) {
            startOverlayService()
        }
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_OPEN_TOOL
            putExtra(OverlayService.EXTRA_TOOL_TYPE, tool.name)
        }
        startService(intent)
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }
}

@Composable
fun MainScreen(
    isServiceRunning: Boolean,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onUpdatePosition: (DockPosition) -> Unit,
    onLaunchTool: (ToolType) -> Unit
) {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var currentPosition by remember { mutableStateOf(DockPreferences.getPosition(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasPermission = Settings.canDrawOverlays(context)
    }

    LaunchedEffect(Unit) {
        hasPermission = Settings.canDrawOverlays(context)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // アプリヘッダー (v1.1.0 バッジ付き)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF27272A)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ViewSidebar,
                        contentDescription = null,
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "SlideDock",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1E3A8A))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("v1.1.0", color = Color(0xFF93C5FD), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(
                        text = "マルチウィンドウ＆エッジハンドル追従ドラッグ対応",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFA1A1AA)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 1. 権限確認カード
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (hasPermission) Color(0xFF1E293B) else Color(0xFF3B1D1D)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasPermission) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (hasPermission) Color(0xFF34D399) else Color(0xFFF87171)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (hasPermission) "オーバーレイ権限: 許可済み" else "オーバーレイ権限: 未許可",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (hasPermission) {
                            "最前面へのハンドル表示および複数フローティングウィンドウの展開が許可されています。"
                        } else {
                            "他アプリの上に表示（SYSTEM_ALERT_WINDOW）権限を有効にする必要があります。"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1)
                    )
                    if (!hasPermission) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                permissionLauncher.launch(intent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("設定画面を開いて許可する", color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. サービス実行状態＆メイン起動・停止ボタン
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "オーバーレイサービス",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isServiceRunning) Color(0xFF065F46) else Color(0xFF3F3F46))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isServiceRunning) "実行中" else "停止中",
                                color = if (isServiceRunning) Color(0xFF34D399) else Color(0xFFA1A1AA),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isServiceRunning) {
                        Button(
                            onClick = onStopService,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("サービスを停止する", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = {
                                if (hasPermission) {
                                    onStartService()
                                } else {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    permissionLauncher.launch(intent)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasPermission) Color(0xFF2563EB) else Color(0xFF4B5563)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (hasPermission) "サービスを開始する" else "権限を許可して開始",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. ツール一覧と直接起動テスト (v1.1.0 新機能)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "マルチタスクツール (直接起動テスト)",
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "画面端のハンドルをタップして展開するか、下の各ボタンから即座にフローティングウィンドウを起動できます。",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFA1A1AA)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val tools = ToolType.values()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (i in tools.indices step 2) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MainToolButton(
                                    tool = tools[i],
                                    modifier = Modifier.weight(1f),
                                    onClick = { onLaunchTool(tools[i]) }
                                )
                                if (i + 1 < tools.size) {
                                    MainToolButton(
                                        tool = tools[i + 1],
                                        modifier = Modifier.weight(1f),
                                        onClick = { onLaunchTool(tools[i + 1]) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. ハンドル配置設定 (左端 / 右端)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "ハンドルの初期表示位置",
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "左端・右端を選択できます。開始後はハンドルを上下に直接ドラッグして任意の位置に移動できます。",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFA1A1AA)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        PositionOptionItem(
                            title = "左端 (Left)",
                            subtitle = "画面左端からスライド",
                            isSelected = currentPosition == DockPosition.LEFT,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                currentPosition = DockPosition.LEFT
                                onUpdatePosition(DockPosition.LEFT)
                            }
                        )

                        PositionOptionItem(
                            title = "右端 (Right)",
                            subtitle = "画面右端からスライド",
                            isSelected = currentPosition == DockPosition.RIGHT,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                currentPosition = DockPosition.RIGHT
                                onUpdatePosition(DockPosition.RIGHT)
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 5. v1.1.0 操作ガイドカード
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF18181B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFBBF24), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "v1.1.0 操作方法と新機能",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    GuideBullet(number = "1", text = "【ハンドル追従ドラッグ】画面端のハンドルを指で上下にドラッグして任意の位置へ移動できます（画面外逸脱防止機能付き）。")
                    GuideBullet(number = "2", text = "【複数ウィンドウ同時展開】ドックから電卓、メモ、時計等をタップすると複数の独立フローティングウィンドウが画面上に出現します。")
                    GuideBullet(number = "3", text = "【ウィンドウ操作】タイトルバーを掴んで移動、右下端でリサイズ、最小化/最大化/閉じるが可能です。")
                    GuideBullet(number = "4", text = "【状態の自動保存】ハンドルの位置やウィンドウの配置はアプリ再起動後も自動で復元されます。")
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}

@Composable
fun MainToolButton(
    tool: ToolType,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF27272A))
            .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = when (tool) {
                    ToolType.CALCULATOR -> Icons.Default.Calculate
                    ToolType.MEMO -> Icons.Default.Description
                    ToolType.CLOCK -> Icons.Default.AccessTime
                    ToolType.TIMER -> Icons.Default.HourglassEmpty
                    ToolType.WEATHER -> Icons.Default.WbSunny
                    ToolType.ASTRONOMY -> Icons.Default.Nightlight
                },
                contentDescription = null,
                tint = Color(0xFF60A5FA),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(tool.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("ウィンドウ起動", color = Color(0xFF94A3B8), fontSize = 10.sp)
            }
        }
    }
}

@Composable
fun PositionOptionItem(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) Color(0xFF1E3A8A) else Color(0xFF27272A))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) Color(0xFF3B82F6) else Color(0xFF3F3F46),
                shape = RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else Color(0xFFE4E4E7),
                    fontSize = 14.sp
                )
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = if (isSelected) Color(0xFF93C5FD) else Color(0xFFA1A1AA)
            )
        }
    }
}

@Composable
fun GuideBullet(number: String, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(Color(0xFF27272A)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = number, fontSize = 11.sp, color = Color(0xFF93C5FD), fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = text, fontSize = 12.sp, color = Color(0xFFD4D4D8), lineHeight = 17.sp)
    }
}