package com.slidedock.app.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.slidedock.app.model.DockPosition

/**
 * WindowManager によるオーバーレイの生成・配置・開閉アニメーション制御
 */
class OverlayManager(private val context: Context) :
    LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private var currentPosition: DockPosition = DockPosition.RIGHT
    private var isExpanded: Boolean = false

    private var rootOverlayView: FrameLayout? = null
    private var handleView: View? = null
    private var panelContainer: FrameLayout? = null

    private var rootParams: WindowManager.LayoutParams? = null

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showHandle(position: DockPosition) {
        if (rootOverlayView != null) return

        currentPosition = position

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val gravity = if (position == DockPosition.LEFT) {
            Gravity.TOP or Gravity.START
        } else {
            Gravity.TOP or Gravity.END
        }

        rootParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            this.y = 300
            this.x = 0
        }

        val root = FrameLayout(context).apply {
            setViewTreeLifecycleOwner(this@OverlayManager)
            setViewTreeViewModelStoreOwner(this@OverlayManager)
            setViewTreeSavedStateRegistryOwner(this@OverlayManager)
        }

        val handle = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@OverlayManager)
            setViewTreeViewModelStoreOwner(this@OverlayManager)
            setViewTreeSavedStateRegistryOwner(this@OverlayManager)
            setContent {
                OverlayHandle(
                    position = currentPosition,
                    isExpanded = isExpanded,
                    onTap = { toggleDock() }
                )
            }
        }

        panelContainer = FrameLayout(context).apply {
            visibility = View.GONE
            val composePanel = ComposeView(context).apply {
                setViewTreeLifecycleOwner(this@OverlayManager)
                setViewTreeViewModelStoreOwner(this@OverlayManager)
                setViewTreeSavedStateRegistryOwner(this@OverlayManager)
                setContent {
                    DockPanelContent(
                        position = currentPosition,
                        onCollapse = { collapseDock() },
                        onPositionChange = { newPos -> updatePosition(newPos) }
                    )
                }
            }
            addView(composePanel)
        }

        root.addView(panelContainer)
        root.addView(handle)

        setupHandleDragListener(handle)

        rootOverlayView = root
        handleView = handle

        windowManager.addView(rootOverlayView, rootParams)
    }

    fun toggleDock() {
        if (isExpanded) {
            collapseDock()
        } else {
            expandDock()
        }
    }

    fun expandDock() {
        if (isExpanded || rootOverlayView == null) return
        isExpanded = true

        rootParams?.apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }
        windowManager.updateViewLayout(rootOverlayView, rootParams)

        panelContainer?.visibility = View.VISIBLE
        animateSlide(isExpand = true)
    }

    fun collapseDock() {
        if (!isExpanded || rootOverlayView == null) return
        isExpanded = false

        animateSlide(isExpand = false) {
            panelContainer?.visibility = View.GONE

            val gravity = if (currentPosition == DockPosition.LEFT) {
                Gravity.TOP or Gravity.START
            } else {
                Gravity.TOP or Gravity.END
            }

            rootParams?.apply {
                width = WindowManager.LayoutParams.WRAP_CONTENT
                height = WindowManager.LayoutParams.WRAP_CONTENT
                flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                this.gravity = gravity
                this.x = 0
            }
            windowManager.updateViewLayout(rootOverlayView, rootParams)
        }
    }

    private fun animateSlide(isExpand: Boolean, onEnd: (() -> Unit)? = null) {
        val targetTranslationX = if (isExpand) 0f else {
            if (currentPosition == DockPosition.LEFT) -600f else 600f
        }
        val startTranslationX = if (isExpand) {
            if (currentPosition == DockPosition.LEFT) -600f else 600f
        } else 0f

        panelContainer?.translationX = startTranslationX

        val animator = ValueAnimator.ofFloat(startTranslationX, targetTranslationX).apply {
            duration = 240
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                panelContainer?.translationX = anim.animatedValue as Float
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    onEnd?.invoke()
                }
            })
        }
        animator.start()
    }

    fun updatePosition(newPosition: DockPosition) {
        currentPosition = newPosition
        if (!isExpanded) {
            val gravity = if (newPosition == DockPosition.LEFT) {
                Gravity.TOP or Gravity.START
            } else {
                Gravity.TOP or Gravity.END
            }
            rootParams?.gravity = gravity
            windowManager.updateViewLayout(rootOverlayView, rootParams)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupHandleDragListener(view: View) {
        var initialY = 0
        var initialTouchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            if (isExpanded) return@setOnTouchListener false

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialY = rootParams?.y ?: 0
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaY = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(deltaY) > 10) {
                        isDragging = true
                        rootParams?.y = initialY + deltaY
                        windowManager.updateViewLayout(rootOverlayView, rootParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        toggleDock()
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun destroy() {
        if (rootOverlayView != null) {
            try {
                windowManager.removeView(rootOverlayView)
            } catch (e: Exception) {
                // Ignore
            }
            rootOverlayView = null
        }
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}