package com.slidedock.app.overlay

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.slidedock.app.model.DockPosition

/**
 * 画面端に常時表示される小さなピル型ハンドル
 */
@Composable
fun OverlayHandle(
    position: DockPosition,
    isExpanded: Boolean,
    onTap: () -> Unit
) {
    val shape = if (position == DockPosition.LEFT) {
        RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
    }

    Box(
        modifier = Modifier
            .shadow(6.dp, shape)
            .clip(shape)
            .background(Color(0xFF1E293B))
            .border(1.dp, Color(0xFF475569), shape)
            .clickable(onClick = onTap)
            .padding(horizontal = 6.dp, vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF94A3B8))
            )
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF38BDF8))
            )
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF94A3B8))
            )
        }
    }
}

/**
 * 展開される補助ドックパネル
 */
@Composable
fun DockPanelContent(
    position: DockPosition,
    onCollapse: () -> Unit,
    onPositionChange: (DockPosition) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onCollapse() }
    ) {
        Box(
            modifier = Modifier
                .align(if (position == DockPosition.LEFT) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(12.dp)
                .width(280.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF18181B))
                .border(1.dp, Color(0xFF27272A), RoundedCornerShape(16.dp))
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { }
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // パネルヘッダー
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF27272A)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewSidebar,
                                contentDescription = null,
                                tint = Color(0xFF60A5FA),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SlideDock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Text(
                                text = "オーバーレイ パネル",
                                fontSize = 11.sp,
                                color = Color(0xFFA1A1AA)
                            )
                        }
                    }

                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (position == DockPosition.LEFT) {
                                Icons.Default.ChevronLeft
                            } else {
                                Icons.Default.ChevronRight
                            },
                            contentDescription = "収納",
                            tint = Color(0xFFA1A1AA)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // ステータス表示
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF27272A))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("状態", fontSize = 12.sp, color = Color(0xFFA1A1AA))
                            Text("アクティブ", fontSize = 12.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("配置端", fontSize = 12.sp, color = Color(0xFFA1A1AA))
                            Text(
                                text = if (position == DockPosition.LEFT) "左端" else "右端",
                                fontSize = 12.sp,
                                color = Color(0xFF93C5FD),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 左右位置クイック切替
                Text(
                    text = "位置の切り替え",
                    fontSize = 12.sp,
                    color = Color(0xFFA1A1AA),
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onPositionChange(DockPosition.LEFT) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (position == DockPosition.LEFT) Color(0xFF2563EB) else Color(0xFF27272A)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            "左端",
                            fontSize = 12.sp,
                            color = if (position == DockPosition.LEFT) Color.White else Color(0xFFA1A1AA)
                        )
                    }

                    Button(
                        onClick = { onPositionChange(DockPosition.RIGHT) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (position == DockPosition.RIGHT) Color(0xFF2563EB) else Color(0xFF27272A)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            "右端",
                            fontSize = 12.sp,
                            color = if (position == DockPosition.RIGHT) Color.White else Color(0xFFA1A1AA)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = onCollapse,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE4E4E7)),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF3F3F46)))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("パネルを閉じる", fontSize = 13.sp)
                }
            }
        }
    }
}