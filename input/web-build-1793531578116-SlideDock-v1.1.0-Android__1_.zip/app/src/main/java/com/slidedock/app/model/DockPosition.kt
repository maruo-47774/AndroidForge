package com.slidedock.app.model

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class DockPosition {
    LEFT,
    RIGHT
}

/**
 * ハンドル位置・上下割合・複数フローティングウィンドウ状態の永続化管理
 * (Android 9+ 互換)
 */
object DockPreferences {
    private const val PREFS_NAME = "slidedock_prefs"
    private const val KEY_POSITION = "key_dock_position"
    private const val KEY_HANDLE_Y_PERCENT = "key_handle_y_percent"
    private const val KEY_WINDOWS_JSON = "key_windows_json"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    // 1. ハンドル左右位置
    fun getPosition(context: Context): DockPosition {
        val name = getPrefs(context).getString(KEY_POSITION, DockPosition.RIGHT.name)
        return try {
            DockPosition.valueOf(name ?: DockPosition.RIGHT.name)
        } catch (e: Exception) {
            DockPosition.RIGHT
        }
    }

    fun savePosition(context: Context, position: DockPosition) {
        getPrefs(context).edit().putString(KEY_POSITION, position.name).apply()
    }

    // 2. ハンドル上下位置割合 (画面回転時にも位置を維持するため 0.0f〜1.0f の比率で保存)
    fun getHandleYPercent(context: Context): Float {
        return getPrefs(context).getFloat(KEY_HANDLE_Y_PERCENT, 0.40f)
    }

    fun saveHandleYPercent(context: Context, percent: Float) {
        val clamped = Math.max(0.06f, Math.min(0.94f, percent))
        getPrefs(context).edit().putFloat(KEY_HANDLE_Y_PERCENT, clamped).apply()
    }

    // 3. ウィンドウ状態の保存と復元
    fun saveWindows(context: Context, windows: List<FloatingWindowModel>) {
        val jsonArray = JSONArray()
        for (win in windows) {
            val obj = JSONObject().apply {
                put("id", win.id)
                put("toolType", win.toolType.name)
                put("x", win.x)
                put("y", win.y)
                put("width", win.width)
                put("height", win.height)
                put("isMinimized", win.isMinimized)
                put("isMaximized", win.isMaximized)
                put("zIndex", win.zIndex)
                put("prevX", win.prevX)
                put("prevY", win.prevY)
                put("prevWidth", win.prevWidth)
                put("prevHeight", win.prevHeight)
            }
            jsonArray.put(obj)
        }
        getPrefs(context).edit().putString(KEY_WINDOWS_JSON, jsonArray.toString()).apply()
    }

    fun getWindows(context: Context): List<FloatingWindowModel> {
        val jsonStr = getPrefs(context).getString(KEY_WINDOWS_JSON, null) ?: return emptyList()
        val list = mutableListOf<FloatingWindowModel>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val toolTypeName = obj.getString("toolType")
                val toolType = try {
                    ToolType.valueOf(toolTypeName)
                } catch (e: Exception) {
                    continue
                }
                list.add(
                    FloatingWindowModel(
                        id = obj.getString("id"),
                        toolType = toolType,
                        x = obj.getInt("x"),
                        y = obj.getInt("y"),
                        width = obj.getInt("width"),
                        height = obj.getInt("height"),
                        isMinimized = obj.optBoolean("isMinimized", false),
                        isMaximized = obj.optBoolean("isMaximized", false),
                        zIndex = obj.optInt("zIndex", 10),
                        prevX = obj.optInt("prevX", obj.getInt("x")),
                        prevY = obj.optInt("prevY", obj.getInt("y")),
                        prevWidth = obj.optInt("prevWidth", obj.getInt("width")),
                        prevHeight = obj.optInt("prevHeight", obj.getInt("height"))
                    )
                )
            }
        } catch (e: Exception) {
            // ignore
        }
        return list
    }
}