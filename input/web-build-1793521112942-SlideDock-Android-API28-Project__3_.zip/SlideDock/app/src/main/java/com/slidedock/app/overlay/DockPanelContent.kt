package com.slidedock.app.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.slidedock.app.model.DockPosition
import com.slidedock.app.model.ToolType

/**
 * 画面端に常時表示される小さなピル型ハンドル (三点リーダーデザイン維持)
 */
@Composable
fun OverlayHandle(
    position: DockPosition,
    isExpanded: Boolean,
    onTap: () -> Unit
) {
    val shape = if (position == DockPosition.LEFT) {
        RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
    }

    Box(
        modifier = Modifier
            .shadow(6.dp, shape)
            .clip(shape)
            .background(Color(0xFF1E293B))
            .border(1.dp, Color(0xFF475569), shape)
            .clickable(onClick = onTap)
            .padding(horizontal = 6.dp, vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF94A3B8))
            )
            Box(
                modifier = Modifier
                    .width(6.dp)
                    .height(if (isExpanded) 12.dp else 6.dp)
                    .clip(CircleShape)
                    .background(if (isExpanded) Color(0xFF60A5FA) else Color(0xFF38BDF8))
            )
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF94A3B8))
            )
        }
    }
}

/**
 * 展開される補助ドックパネル (6種類のツール一覧)
 */
@Composable
fun DockPanelContent(
    position: DockPosition,
    onCollapse: () -> Unit,
    onPositionChange: (DockPosition) -> Unit,
    onOpenTool: (ToolType) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onCollapse() }
    ) {
        Box(
            modifier = Modifier
                .align(if (position == DockPosition.LEFT) Alignment.CenterStart else Alignment.CenterEnd)
                .padding(12.dp)
                .width(280.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF18181B))
                .border(1.dp, Color(0xFF27272A), RoundedCornerShape(16.dp))
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { }
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF27272A)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewSidebar,
                                contentDescription = null,
                                tint = Color(0xFF60A5FA),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SlideDock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Text(
                                text = "ツール一覧",
                                fontSize = 11.sp,
                                color = Color(0xFFA1A1AA)
                            )
                        }
                    }

                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (position == DockPosition.LEFT) {
                                Icons.Default.ChevronLeft
                            } else {
                                Icons.Default.ChevronRight
                            },
                            contentDescription = "収納",
                            tint = Color(0xFFA1A1AA)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "マルチタスクツール (選択して起動)",
                    fontSize = 11.sp,
                    color = Color(0xFFA1A1AA),
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                val tools = ToolType.values()
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in tools.indices step 2) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ToolGridButton(
                                tool = tools[i],
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    onOpenTool(tools[i])
                                    onCollapse()
                                }
                            )
                            if (i + 1 < tools.size) {
                                ToolGridButton(
                                    tool = tools[i + 1],
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        onOpenTool(tools[i + 1])
                                        onCollapse()
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("ハンドル位置", fontSize = 11.sp, color = Color(0xFFA1A1AA))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Button(
                            onClick = { onPositionChange(DockPosition.LEFT) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (position == DockPosition.LEFT) Color(0xFF2563EB) else Color(0xFF27272A)
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("左端", fontSize = 10.sp, color = Color.White)
                        }
                        Button(
                            onClick = { onPositionChange(DockPosition.RIGHT) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (position == DockPosition.RIGHT) Color(0xFF2563EB) else Color(0xFF27272A)
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("右端", fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolGridButton(
    tool: ToolType,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF27272A))
            .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = when (tool) {
                    ToolType.CALCULATOR -> Icons.Default.Calculate
                    ToolType.MEMO -> Icons.Default.Description
                    ToolType.CLOCK -> Icons.Default.AccessTime
                    ToolType.TIMER -> Icons.Default.HourglassEmpty
                    ToolType.WEATHER -> Icons.Default.WbSunny
                    ToolType.ASTRONOMY -> Icons.Default.Nightlight
                },
                contentDescription = null,
                tint = Color(0xFF60A5FA),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(tool.title, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(tool.subtitle, color = Color(0xFFA1A1AA), fontSize = 9.sp, maxLines = 1)
            }
        }
    }
}