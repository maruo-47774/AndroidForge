package com.slidedock.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.slidedock.app.MainActivity
import com.slidedock.app.R
import com.slidedock.app.model.DockPosition
import com.slidedock.app.model.DockPreferences
import com.slidedock.app.model.ToolType
import com.slidedock.app.overlay.OverlayManager

/**
 * SlideDock を管理するフォアグラウンドサービス
 */
class OverlayService : Service() {

    private var overlayManager: OverlayManager? = null

    companion object {
        const val CHANNEL_ID = "slidedock_foreground_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.slidedock.app.action.START"
        const val ACTION_STOP = "com.slidedock.app.action.STOP"
        const val ACTION_UPDATE_POSITION = "com.slidedock.app.action.UPDATE_POSITION"
        const val ACTION_OPEN_TOOL = "com.slidedock.app.action.OPEN_TOOL"
        const val ACTION_STATE_CHANGED = "com.slidedock.app.action.STATE_CHANGED"

        const val EXTRA_IS_RUNNING = "extra_is_running"
        const val EXTRA_POSITION = "extra_position"
        const val EXTRA_TOOL_TYPE = "extra_tool_type"

        var isRunning: Boolean = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        overlayManager = OverlayManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE_POSITION -> {
                val positionName = intent.getStringExtra(EXTRA_POSITION)
                val position = if (positionName != null) {
                    DockPosition.valueOf(positionName)
                } else {
                    DockPreferences.getPosition(this)
                }
                overlayManager?.updatePosition(position)
            }
            ACTION_OPEN_TOOL -> {
                val toolName = intent.getStringExtra(EXTRA_TOOL_TYPE)
                if (toolName != null) {
                    try {
                        val tool = ToolType.valueOf(toolName)
                        overlayManager?.floatingWindowManager?.openToolWindow(tool)
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
            ACTION_START, null -> {
                startForegroundServiceWithNotification()
                val position = DockPreferences.getPosition(this)
                overlayManager?.showHandle(position)
                setRunningState(true)
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val activeCount = overlayManager?.floatingWindowManager?.getActiveWindowsCount() ?: 0
        val contentText = if (activeCount > 0) {
            "現在 ${activeCount} 個のフローティングウィンドウが稼働中"
        } else {
            "画面端のハンドルをタップしてドックパネルを展開できます"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SlideDock は実行中です")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "停止",
                stopPendingIntent
            )
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "SlideDock オーバーレイサービス",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "画面端オーバーレイドックの表示状態を維持するための常駐通知です"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun setRunningState(running: Boolean) {
        isRunning = running
        val broadcastIntent = Intent(ACTION_STATE_CHANGED).apply {
            putExtra(EXTRA_IS_RUNNING, running)
            setPackage(packageName)
        }
        sendBroadcast(broadcastIntent)
    }

    override fun onDestroy() {
        super.onDestroy()
        overlayManager?.destroy()
        overlayManager = null
        setRunningState(false)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}