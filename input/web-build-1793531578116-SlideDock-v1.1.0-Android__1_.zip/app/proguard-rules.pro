# SlideDock Proguard Rules for Release Builds
-keepattributes *Annotation*
-dontwarn androidx.compose.**