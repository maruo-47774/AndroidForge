package com.slidedock.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.*
import com.slidedock.app.model.DockPreferences
import com.slidedock.app.model.FloatingWindowModel
import com.slidedock.app.model.ToolType

/**
 * Android WindowManager を使用した複数のフローティングウィンドウ独立管理クラス
 *
 * 【改善点】
 * 1. タイトルバードラッグによる確実な指追従移動（DragStartでWindowを再破棄しない設計）
 * 2. 画面外への完全離脱防止クランプ（タイトルバーと本体が常に操作可能な領域に留まる）
 * 3. ウィンドウタップ時またはドラッグ終了時のスムーズな最前面化 (bringToFront)
 * 4. 最小化・最大化・復元・リサイズ・閉じる操作と独立状態の SharedPreferences 永続化
 */
class FloatingWindowManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val viewModelStoreOwner: ViewModelStoreOwner,
    private val savedStateRegistryOwner: SavedStateRegistryOwner
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val activeWindows = LinkedHashMap<String, WindowViewHolder>()

    // ウィンドウの重なり順（Z-Order）を一元管理するリスト（先頭が最背面、末尾が最前面）
    // 最小化されたウィンドウや閉じられたウィンドウはここから除外される
    private val windowZOrder = mutableListOf<String>()

    data class WindowViewHolder(
        val model: FloatingWindowModel,
        val rootView: FrameLayout,
        val layoutParams: WindowManager.LayoutParams
    )

    /**
     * 指定されたウィンドウが現在最前面（Z-Orderのトップ）にあるか判定
     */
    fun isTopWindow(id: String): Boolean = windowZOrder.lastOrNull() == id

    /**
     * 現在最前面に表示されているウィンドウIDを取得
     */
    fun getTopWindowId(): String? = windowZOrder.lastOrNull()

    /**
     * 現在の重なり順リスト（背面 -> 前面）を取得
     */
    fun getZOrder(): List<String> = windowZOrder.toList()

    private fun getScreenWidth(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.widthPixels
    }

    private fun getScreenHeight(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.heightPixels
    }

    private fun dpToPx(dp: Int): Int {
        val density = context.resources.displayMetrics.density
        return (dp * density).toInt()
    }

    /**
     * ツールに対応する独立フローティングウィンドウを開く
     */
    fun openToolWindow(toolType: ToolType) {
        val existing = activeWindows.values.find { it.model.toolType == toolType }
        if (existing != null) {
            if (existing.model.isMinimized) {
                restoreWindow(existing.model.id)
            } else {
                bringToFront(existing.model.id)
            }
            return
        }

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()
        val defaultW = Math.min(screenW - dpToPx(32), dpToPx(toolType.defaultWidthDp))
        val defaultH = Math.min(screenH - dpToPx(64), dpToPx(toolType.defaultHeightDp))

        // 重複配置を避けるオフセット計算
        val offset = (activeWindows.size % 5) * dpToPx(28)
        val initialX = Math.max(dpToPx(16), Math.min(screenW - defaultW - dpToPx(16), dpToPx(36) + offset))
        val initialY = Math.max(dpToPx(36), Math.min(screenH - defaultH - dpToPx(36), dpToPx(50) + offset))

        val model = FloatingWindowModel(
            id = "win_${toolType.name}_${System.currentTimeMillis()}",
            toolType = toolType,
            x = initialX,
            y = initialY,
            width = defaultW,
            height = defaultH
        )

        createAndAddWindow(model)
        saveState()
    }

    fun restoreSavedWindows() {
        val saved = DockPreferences.getWindows(context)
        for (model in saved) {
            if (!model.isMinimized) {
                createAndAddWindow(model)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createAndAddWindow(model: FloatingWindowModel) {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            model.width,
            model.height,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = model.x
            y = model.y
        }

        val rootView = object : FrameLayout(context) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                // タッチ開始（ACTION_DOWN）時に、このウィンドウが最前面でなければ即座に最前面へ昇格
                // post で非同期キューに入れることで、現在のタッチディスパッチ完了直後に WindowManager を安全に更新
                if (ev.action == MotionEvent.ACTION_DOWN) {
                    if (!isTopWindow(model.id)) {
                        post {
                            bringToFront(model.id)
                        }
                    }
                }
                return super.dispatchTouchEvent(ev)
            }
        }.apply {
            setViewTreeLifecycleOwner(this@FloatingWindowManager.lifecycleOwner)
            setViewTreeViewModelStoreOwner(this@FloatingWindowManager.viewModelStoreOwner)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowManager.savedStateRegistryOwner)
        }

        val composeView = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowManager.lifecycleOwner)
            setViewTreeViewModelStoreOwner(this@FloatingWindowManager.viewModelStoreOwner)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowManager.savedStateRegistryOwner)
            setContent {
                FloatingWindowView(
                    model = model,
                    onFocus = {
                        if (!isTopWindow(model.id)) {
                            bringToFront(model.id)
                        }
                    },
                    onMinimize = { minimizeWindow(model.id) },
                    onToggleMaximize = { toggleMaximizeWindow(model.id) },
                    onClose = { closeWindow(model.id) },
                    onDragMove = { deltaX, deltaY ->
                        moveWindow(model.id, deltaX.toInt(), deltaY.toInt())
                    },
                    onDragEnd = {
                        saveState()
                    },
                    onResizeMove = { deltaW, deltaH ->
                        resizeWindow(model.id, deltaW.toInt(), deltaH.toInt())
                    },
                    onResizeEnd = { saveState() }
                )
            }
        }

        rootView.addView(composeView)

        try {
            windowManager.addView(rootView, params)
            activeWindows[model.id] = WindowViewHolder(model, rootView, params)
            windowZOrder.remove(model.id)
            windowZOrder.add(model.id)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * タイトルバードラッグによる指追従移動＆画面外逸脱防止クランプ
     */
    fun moveWindow(id: String, deltaX: Int, deltaY: Int) {
        val holder = activeWindows[id] ?: return
        if (holder.model.isMaximized) return

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        var newX = holder.layoutParams.x + deltaX
        var newY = holder.layoutParams.y + deltaY

        // 画面外への完全離脱防止クランプ
        // 左右に少なくとも 60dp、タイトルバー(38dp)が画面上端〜下端に収まるように制限
        val minVisibleX = dpToPx(60)
        val minVisibleY = dpToPx(38)
        newX = Math.max(-holder.layoutParams.width + minVisibleX, Math.min(screenW - minVisibleX, newX))
        newY = Math.max(0, Math.min(screenH - minVisibleY, newY))

        holder.layoutParams.x = newX
        holder.layoutParams.y = newY
        holder.model.x = newX
        holder.model.y = newY

        try {
            windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    /**
     * 右下グリップによるウィンドウサイズ変更
     */
    fun resizeWindow(id: String, deltaW: Int, deltaH: Int) {
        val holder = activeWindows[id] ?: return
        if (holder.model.isMaximized) return

        val minW = dpToPx(180)
        val minH = dpToPx(140)
        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        var newW = holder.layoutParams.width + deltaW
        var newH = holder.layoutParams.height + deltaH

        newW = Math.max(minW, Math.min(screenW - holder.layoutParams.x, newW))
        newH = Math.max(minH, Math.min(screenH - holder.layoutParams.y, newH))

        holder.layoutParams.width = newW
        holder.layoutParams.height = newH
        holder.model.width = newW
        holder.model.height = newH

        try {
            windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun toggleMaximizeWindow(id: String) {
        val holder = activeWindows[id] ?: return
        bringToFront(id) // 最大化・復元時にも最前面を維持

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        if (holder.model.isMaximized) {
            // 復元
            holder.model.isMaximized = false
            holder.layoutParams.x = holder.model.prevX
            holder.layoutParams.y = holder.model.prevY
            holder.layoutParams.width = holder.model.prevWidth
            holder.layoutParams.height = holder.model.prevHeight
        } else {
            // 最大化（元の座標・サイズを保存）
            holder.model.isMaximized = true
            holder.model.prevX = holder.layoutParams.x
            holder.model.prevY = holder.layoutParams.y
            holder.model.prevWidth = holder.layoutParams.width
            holder.model.prevHeight = holder.layoutParams.height

            holder.layoutParams.x = dpToPx(8)
            holder.layoutParams.y = dpToPx(8)
            holder.layoutParams.width = screenW - dpToPx(16)
            holder.layoutParams.height = screenH - dpToPx(16)
        }

        try {
            windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    /**
     * ウィンドウを最小化（重なり順管理の対象から除外）
     */
    fun minimizeWindow(id: String) {
        val holder = activeWindows.remove(id) ?: return
        holder.model.isMinimized = true
        windowZOrder.remove(id) // 最小化中は重なり順から除外
        try {
            windowManager.removeView(holder.rootView)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    /**
     * 最小化ウィンドウを復元（最前面に追加）
     */
    fun restoreWindow(id: String) {
        val saved = DockPreferences.getWindows(context)
        val model = saved.find { it.id == id } ?: return
        model.isMinimized = false
        createAndAddWindow(model)
        bringToFront(model.id)
        saveState()
    }

    /**
     * ウィンドウを閉じる（重なり順から除去し、最上位を適切に更新）
     */
    fun closeWindow(id: String) {
        val holder = activeWindows.remove(id) ?: return
        windowZOrder.remove(id) // 重なり順から除去
        try {
            windowManager.removeView(holder.rootView)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    /**
     * 指定されたウィンドウを一元管理の最前面（Z-Orderのトップ）に移動する
     * - すでに最前面（isTopWindow == true）の場合は無駄なビュー操作をスキップし、ドラッグを維持
     * - 最前面でない場合、WindowManager から removeView & addView して最上位に配置
     */
    fun bringToFront(id: String) {
        val holder = activeWindows[id] ?: return
        if (isTopWindow(id)) return // すでに最前面

        // 重なり順リストの末尾（最前面）へ移動
        windowZOrder.remove(id)
        windowZOrder.add(id)

        // activeWindows の LinkedHashMap 順序も末尾へ
        activeWindows.remove(id)
        activeWindows[id] = holder

        try {
            windowManager.removeView(holder.rootView)
            windowManager.addView(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    fun getActiveWindowsCount(): Int = activeWindows.size

    private fun saveState() {
        // 重なり順（Z-Order）順にアクティブウィンドウを保存
        val activeModels = windowZOrder.mapNotNull { activeWindows[it]?.model }
        val saved = DockPreferences.getWindows(context)
        val minimizedList = saved.filter { it.isMinimized }
        DockPreferences.saveWindows(context, activeModels + minimizedList)
    }

    fun destroy() {
        for (holder in activeWindows.values) {
            try {
                windowManager.removeView(holder.rootView)
            } catch (e: Exception) {
                // ignore
            }
        }
        activeWindows.clear()
        windowZOrder.clear()
    }
}