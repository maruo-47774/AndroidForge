package com.slidedock.app.model

import android.content.Context
import android.content.SharedPreferences

enum class DockPosition {
    LEFT,
    RIGHT
}

object DockPreferences {
    private const val PREFS_NAME = "slidedock_prefs"
    private const val KEY_POSITION = "key_dock_position"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getPosition(context: Context): DockPosition {
        val name = getPrefs(context).getString(KEY_POSITION, DockPosition.RIGHT.name)
        return try {
            DockPosition.valueOf(name ?: DockPosition.RIGHT.name)
        } catch (e: Exception) {
            DockPosition.RIGHT
        }
    }

    fun savePosition(context: Context, position: DockPosition) {
        getPrefs(context).edit().putString(KEY_POSITION, position.name).apply()
    }
}