package com.slidedock.app.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.slidedock.app.model.DockPosition
import com.slidedock.app.model.ToolType

/**
 * 画面端に常時表示される小さなピル型ハンドル
 *
 * 【改善点】
 * - 左端配置：左側を画面端に密着させ、右側（画面内向き）に角丸・余白を設ける。
 * - 右端配置：右側を画面端に密着させ、左側（画面内向き）に角丸・余白を設ける。
 * - 三点リーダー（上下の丸＋中央のインジケーターピル）の視認性を高コントラストで維持。
 */
@Composable
fun OverlayHandle(
    position: DockPosition,
    isExpanded: Boolean,
    modifier: Modifier = Modifier
) {
    val isLeft = position == DockPosition.LEFT

    val shape = if (isLeft) {
        RoundedCornerShape(topStart = 0.dp, bottomStart = 0.dp, topEnd = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp, topEnd = 0.dp, bottomEnd = 0.dp)
    }

    val borderColor = if (isExpanded) Color(0xFF60A5FA) else Color(0xFF475569)
    val bgColor = if (isExpanded) Color(0xFF1E3A8A) else Color(0xFF1E293B)

    Box(
        modifier = modifier
            .shadow(8.dp, shape)
            .clip(shape)
            .background(bgColor)
            .border(1.dp, borderColor, shape)
            .padding(
                start = if (isLeft) 6.dp else 9.dp,
                end = if (isLeft) 9.dp else 6.dp,
                top = 18.dp,
                bottom = 18.dp
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(if (isExpanded) Color(0xFF93C5FD) else Color(0xFF94A3B8))
            )
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .height(if (isExpanded) 16.dp else 8.dp)
                    .clip(RoundedCornerShape(2.5.dp))
                    .background(if (isExpanded) Color(0xFF60A5FA) else Color(0xFF38BDF8))
            )
            Box(
                modifier = Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(if (isExpanded) Color(0xFF93C5FD) else Color(0xFF94A3B8))
            )
        }
    }
}

/**
 * 展開される補助ドックパネル (6種類のツール一覧 ＆ 左右配置切替)
 */
@Composable
fun DockPanelContent(
    position: DockPosition,
    onCollapse: () -> Unit,
    onPositionChange: (DockPosition) -> Unit,
    onOpenTool: (ToolType) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                start = if (position == DockPosition.LEFT) 16.dp else 40.dp,
                end = if (position == DockPosition.RIGHT) 16.dp else 40.dp,
                top = 24.dp,
                bottom = 24.dp
            ),
        contentAlignment = if (position == DockPosition.LEFT) Alignment.CenterStart else Alignment.CenterEnd
    ) {
        Box(
            modifier = Modifier
                .widthIn(min = 280.dp, max = 320.dp)
                .wrapContentHeight()
                .shadow(16.dp, RoundedCornerShape(18.dp))
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF18181B))
                .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(18.dp))
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { /* パネル内タップは通過させない */ }
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // 1. パネルヘッダー
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF27272A))
                                .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ViewSidebar,
                                contentDescription = null,
                                tint = Color(0xFF60A5FA),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SlideDock",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                            Text(
                                text = "マルチタスクパネル",
                                fontSize = 11.sp,
                                color = Color(0xFFA1A1AA)
                            )
                        }
                    }

                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF27272A))
                    ) {
                        Icon(
                            imageVector = if (position == DockPosition.LEFT) {
                                Icons.Default.ChevronLeft
                            } else {
                                Icons.Default.ChevronRight
                            },
                            contentDescription = "収納",
                            tint = Color(0xFFE4E4E7),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. 左右配置切り替えボタン
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF27272A))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PositionSwitchButton(
                        title = "左端 (Left)",
                        isSelected = position == DockPosition.LEFT,
                        modifier = Modifier.weight(1f),
                        onClick = { onPositionChange(DockPosition.LEFT) }
                    )
                    PositionSwitchButton(
                        title = "右端 (Right)",
                        isSelected = position == DockPosition.RIGHT,
                        modifier = Modifier.weight(1f),
                        onClick = { onPositionChange(DockPosition.RIGHT) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "マルチタスクツール (タップで起動)",
                    fontSize = 11.sp,
                    color = Color(0xFFA1A1AA),
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 3. 6種類のツール一覧グリッド
                val tools = ToolType.values()
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (i in tools.indices step 2) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ToolGridButton(
                                tool = tools[i],
                                modifier = Modifier.weight(1f),
                                onClick = { onOpenTool(tools[i]) }
                            )
                            if (i + 1 < tools.size) {
                                ToolGridButton(
                                    tool = tools[i + 1],
                                    modifier = Modifier.weight(1f),
                                    onClick = { onOpenTool(tools[i + 1]) }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "※ハンドルを上下にドラッグして位置を調整できます",
                    fontSize = 10.sp,
                    color = Color(0xFF71717A)
                )
            }
        }
    }
}

@Composable
fun PositionSwitchButton(
    title: String,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) Color(0xFF2563EB) else Color.Transparent)
            .clickable { onClick() }
            .padding(vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else Color(0xFFA1A1AA)
        )
    }
}

@Composable
fun ToolGridButton(
    tool: ToolType,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF27272A))
            .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (tool) {
                        ToolType.CALCULATOR -> Icons.Default.Calculate
                        ToolType.MEMO -> Icons.Default.Description
                        ToolType.CLOCK -> Icons.Default.AccessTime
                        ToolType.TIMER -> Icons.Default.HourglassEmpty
                        ToolType.WEATHER -> Icons.Default.WbSunny
                        ToolType.ASTRONOMY -> Icons.Default.Nightlight
                    },
                    contentDescription = null,
                    tint = Color(0xFF60A5FA),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = tool.title,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = tool.subtitle,
                    color = Color(0xFFA1A1AA),
                    fontSize = 9.sp,
                    maxLines = 1
                )
            }
        }
    }
}