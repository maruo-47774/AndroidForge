package com.slidedock.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import androidx.savedstate.*
import com.slidedock.app.model.DockPosition
import com.slidedock.app.model.DockPreferences
import com.slidedock.app.model.ToolType

/**
 * WindowManager によるエッジハンドル、ドックパネル、および FloatingWindowManager の統括クラス
 *
 * 【不具合修正・機能強化】
 * 1. エッジハンドルの上下ドラッグ移動 (MotionEvent.rawY による指完全追従 & 画面外逸脱防止クランプ)
 * 2. ドラッグ移動とタップ操作の明確な区別 (TouchSlop判定、ドラッグ終了時の SharedPreferences 比率保存)
 * 3. 左右配置切り替え (左端 ⇔ 右端のリアルタイム更新、WindowManager LayoutParams 更新 & 永続化)
 * 4. 左右独立ハンドルUI (左端・右端それぞれの形状・余白・三点リーダー視認性維持)
 * 5. パネル開閉の確実な連動 (タップで開く/再タップで閉じる/外側タップで閉じる、サービスは継続)
 * 6. 6種類のマルチタスクツール一覧表示とウィンドウ起動連携
 */
class OverlayManager(private val context: Context) :
    LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val store = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    val currentPositionState = mutableStateOf(DockPosition.RIGHT)
    val isExpandedState = mutableStateOf(false)

    private var rootOverlayView: ComposeView? = null
    private var rootParams: WindowManager.LayoutParams? = null
    private var currentY: Int = 0

    val floatingWindowManager = FloatingWindowManager(context, this, this, this)

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    private fun getScreenWidth(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.widthPixels
    }

    private fun getScreenHeight(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.heightPixels
    }

    private fun dpToPx(dp: Int): Int {
        val density = context.resources.displayMetrics.density
        return (dp * density).toInt()
    }

    /**
     * 画面回転検知時の処理：
     * 1. 新しい画面高さに基づいてエッジハンドルの位置を比率から再計算し画面内にクランプ
     * 2. ドック展開中の場合は全画面サイズに追従
     * 3. フローティングウィンドウマネージャへ回転イベントを委譲
     */
    fun onConfigurationChanged(newConfig: Configuration) {
        val screenH = getScreenHeight()
        val savedPercent = DockPreferences.getHandleYPercent(context)
        val minY = dpToPx(16)
        val maxY = Math.max(minY, screenH - dpToPx(90))
        currentY = ((screenH * savedPercent).toInt()).coerceIn(minY, maxY)

        if (rootOverlayView != null && rootParams != null) {
            if (isExpandedState.value) {
                rootParams?.width = WindowManager.LayoutParams.MATCH_PARENT
                rootParams?.height = WindowManager.LayoutParams.MATCH_PARENT
            } else {
                rootParams?.y = currentY
            }
            try {
                windowManager.updateViewLayout(rootOverlayView, rootParams)
            } catch (e: Exception) {
                // ignore
            }
        }

        // フローティングウィンドウの再配置・サイズ再計算
        floatingWindowManager.onConfigurationChanged(newConfig)
    }

    @SuppressLint("ClickableViewAccessibility")
    fun showHandle(position: DockPosition) {
        if (rootOverlayView != null) return

        currentPositionState.value = position
        isExpandedState.value = false

        val screenH = getScreenHeight()
        val savedPercent = DockPreferences.getHandleYPercent(context)
        currentY = (screenH * savedPercent).toInt()

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val gravity = if (position == DockPosition.LEFT) {
            Gravity.TOP or Gravity.START
        } else {
            Gravity.TOP or Gravity.END
        }

        rootParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            this.gravity = gravity
            this.y = currentY
            this.x = 0
        }

        val composeView = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@OverlayManager)
            setViewTreeViewModelStoreOwner(this@OverlayManager)
            setViewTreeSavedStateRegistryOwner(this@OverlayManager)
            setContent {
                val isExpanded by remember { isExpandedState }
                val currentPos by remember { currentPositionState }

                if (!isExpanded) {
                    OverlayHandle(
                        position = currentPos,
                        isExpanded = false
                    )
                } else {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0x66000000))
                                .clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ) {
                                    collapseDock()
                                }
                        )

                        DockPanelContent(
                            position = currentPos,
                            onCollapse = { collapseDock() },
                            onPositionChange = { newPos -> updatePosition(newPos) },
                            onOpenTool = { tool ->
                                floatingWindowManager.openToolWindow(tool)
                                collapseDock()
                            }
                        )

                        Box(
                            modifier = Modifier
                                .align(if (currentPos == DockPosition.LEFT) Alignment.TopStart else Alignment.TopEnd)
                                .offset(y = with(LocalDensity.current) { currentY.toDp() })
                                .clickable(
                                    indication = null,
                                    interactionSource = remember { MutableInteractionSource() }
                                ) {
                                    collapseDock()
                                }
                        ) {
                            OverlayHandle(
                                position = currentPos,
                                isExpanded = true
                            )
                        }
                    }
                }
            }
        }

        setupHandleTouchListener(composeView)
        rootOverlayView = composeView

        try {
            windowManager.addView(rootOverlayView, rootParams)
        } catch (e: Exception) {
            // ignore
        }

        floatingWindowManager.restoreSavedWindows()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupHandleTouchListener(view: View) {
        var initialWindowY = 0
        var initialTouchRawY = 0f
        var isDragging = false
        val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

        view.setOnTouchListener { _, event ->
            if (isExpandedState.value) {
                return@setOnTouchListener false
            }

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialWindowY = rootParams?.y ?: 0
                    initialTouchRawY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaRawY = event.rawY - initialTouchRawY
                    if (Math.abs(deltaRawY) > touchSlop) {
                        isDragging = true
                        val screenH = getScreenHeight()
                        val targetY = (initialWindowY + deltaRawY).toInt()

                        val minY = dpToPx(16)
                        val maxY = screenH - dpToPx(90)
                        val clampedY = Math.max(minY, Math.min(maxY, targetY))

                        currentY = clampedY
                        rootParams?.y = clampedY
                        try {
                            windowManager.updateViewLayout(rootOverlayView, rootParams)
                        } catch (e: Exception) {
                            // ignore
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        val screenH = getScreenHeight()
                        val percent = currentY.toFloat() / screenH.toFloat()
                        DockPreferences.saveHandleYPercent(context, percent)
                    } else {
                        expandDock()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) {
                        val screenH = getScreenHeight()
                        val percent = currentY.toFloat() / screenH.toFloat()
                        DockPreferences.saveHandleYPercent(context, percent)
                    }
                    true
                }
                else -> false
            }
        }
    }

    fun toggleDock() {
        if (isExpandedState.value) {
            collapseDock()
        } else {
            expandDock()
        }
    }

    fun expandDock() {
        if (isExpandedState.value || rootOverlayView == null) return
        isExpandedState.value = true

        rootParams?.apply {
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            windowManager.updateViewLayout(rootOverlayView, rootParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun collapseDock() {
        if (!isExpandedState.value || rootOverlayView == null) return
        isExpandedState.value = false

        val screenH = getScreenHeight()
        val savedPercent = DockPreferences.getHandleYPercent(context)
        currentY = (screenH * savedPercent).toInt()

        val gravity = if (currentPositionState.value == DockPosition.LEFT) {
            Gravity.TOP or Gravity.START
        } else {
            Gravity.TOP or Gravity.END
        }

        rootParams?.apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            this.gravity = gravity
            this.x = 0
            this.y = currentY
        }

        try {
            windowManager.updateViewLayout(rootOverlayView, rootParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun updatePosition(newPosition: DockPosition) {
        currentPositionState.value = newPosition
        DockPreferences.savePosition(context, newPosition)

        if (!isExpandedState.value && rootOverlayView != null) {
            val gravity = if (newPosition == DockPosition.LEFT) {
                Gravity.TOP or Gravity.START
            } else {
                Gravity.TOP or Gravity.END
            }
            rootParams?.apply {
                this.gravity = gravity
                this.x = 0
            }
            try {
                windowManager.updateViewLayout(rootOverlayView, rootParams)
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    fun destroy() {
        floatingWindowManager.destroy()
        if (rootOverlayView != null) {
            try {
                windowManager.removeView(rootOverlayView)
            } catch (e: Exception) {
                // ignore
            }
            rootOverlayView = null
        }
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}