package com.slidedock.app.model

/**
 * SlideDock で提供される補助マルチタスクツール定義
 */
enum class ToolType(
    val title: String,
    val subtitle: String,
    val defaultWidthDp: Int,
    val defaultHeightDp: Int
) {
    CALCULATOR("電卓", "四則演算・数値入力", 260, 320),
    MEMO("メモ", "クイックテキスト保存", 280, 280),
    CLOCK("時計", "世界時計・秒針表示", 250, 220),
    TIMER("タイマー", "カウントダウン計測", 250, 230),
    WEATHER("天気", "現在地の気象情報", 270, 260),
    ASTRONOMY("天文・暦", "月齢・二十四節気・暦注", 280, 270)
}

/**
 * フローティングウィンドウの独立状態モデル
 */
data class FloatingWindowModel(
    val id: String,
    val toolType: ToolType,
    var x: Int,
    var y: Int,
    var width: Int,
    var height: Int,
    var isMinimized: Boolean = false,
    var isMaximized: Boolean = false,
    var zIndex: Int = 10,
    var prevX: Int = x,
    var prevY: Int = y,
    var prevWidth: Int = width,
    var prevHeight: Int = height
)