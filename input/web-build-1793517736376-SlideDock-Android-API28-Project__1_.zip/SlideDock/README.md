# SlideDock - Android 9+ Overlay Dock App

画面端から補助パネルを呼び出せるオーバーレイ型マルチタスクアプリです。

## 主な仕様
- **ターゲット**: Android 9 (API 28) 以上
- **UI フレームワーク**: Kotlin + Jetpack Compose (Material3)
- **テーマ**: ダークテーマ（暗色基調、角丸16dp、控えめなアニメーション）
- **最適化解像度**: スマホおよび 1280×800 タブレット対応

## リソース構造 (AAPT2完全準拠)
- `res/xml/data_extraction_rules.xml` (Android 12+ バックアップルール)
- `res/xml/backup_rules.xml` (Android 6.0〜11 レガシーバックアップルール)
- `res/mipmap-anydpi-v26/ic_launcher.xml` & `ic_launcher_round.xml`
- `res/drawable/ic_launcher_foreground.xml` & `res/values/colors.xml` (`ic_launcher_background`)
- `res/drawable/ic_notification.xml` (フォアグラウンドサービス通知アイコン)
- `app/proguard-rules.pro` (Release ビルド難読化設定)

## ビルドコマンド
```bash
# Debug ビルド
./gradlew assembleDebug

# Release ビルド
./gradlew assembleRelease
```