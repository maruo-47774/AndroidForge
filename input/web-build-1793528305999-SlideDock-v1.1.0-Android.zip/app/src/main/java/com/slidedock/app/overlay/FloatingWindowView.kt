package com.slidedock.app.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.slidedock.app.model.FloatingWindowModel
import com.slidedock.app.model.ToolType

/**
 * 個別フローティングウィンドウの Jetpack Compose UI 実装
 *
 * 【改善点】
 * 1. タイトルバーのタイトル/アイコン領域をドラッグ専用サーフェスとして分離し、指追従の移動を実現。
 * 2. 最小化・最大化・閉じるボタンのタップ領域をドラッグ判定と干渉させず、100%確実に反応するように調整。
 * 3. 画面外への完全離脱防止クランプに対応。
 * 4. 右下リサイズグリップでのスムーズなサイズ変更を維持。
 */
@Composable
fun FloatingWindowView(
    model: FloatingWindowModel,
    onMinimize: () -> Unit,
    onToggleMaximize: () -> Unit,
    onClose: () -> Unit,
    onDragMove: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onResizeMove: (Float, Float) -> Unit,
    onResizeEnd: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .shadow(12.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF18181B))
            .border(1.dp, Color(0xFF3F3F46), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // タイトルバー (高さ 38dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .background(Color(0xFF27272A))
                    .padding(start = 8.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // 1. タイトル＆ドラッグ領域 (ボタン以外の全領域をドラッグ可能にする)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDrag = { change, dragAmount ->
                                    change.consume()
                                    onDragMove(dragAmount.x, dragAmount.y)
                                },
                                onDragEnd = { onDragEnd() },
                                onDragCancel = { onDragEnd() }
                            )
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = when (model.toolType) {
                            ToolType.CALCULATOR -> Icons.Default.Calculate
                            ToolType.MEMO -> Icons.Default.Description
                            ToolType.CLOCK -> Icons.Default.AccessTime
                            ToolType.TIMER -> Icons.Default.HourglassEmpty
                            ToolType.WEATHER -> Icons.Default.WbSunny
                            ToolType.ASTRONOMY -> Icons.Default.Nightlight
                        },
                        contentDescription = null,
                        tint = Color(0xFF60A5FA),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = model.toolType.title,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 2. ウィンドウ制御ボタン群 (最小化, 最大化, 閉じる) - ドラッグ判定と完全に分離
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onMinimize,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Minimize,
                            contentDescription = "最小化",
                            tint = Color(0xFFA1A1AA),
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleMaximize,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (model.isMaximized) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = "最大化/復元",
                            tint = Color(0xFFA1A1AA),
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "閉じる",
                            tint = Color(0xFFF87171),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // ウィンドウコンテンツ領域
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color(0xFF121215))
                    .padding(8.dp)
            ) {
                when (model.toolType) {
                    ToolType.CALCULATOR -> PlaceholderCalculatorView()
                    ToolType.MEMO -> PlaceholderMemoView()
                    ToolType.CLOCK -> PlaceholderClockView()
                    ToolType.TIMER -> PlaceholderTimerView()
                    ToolType.WEATHER -> PlaceholderWeatherView()
                    ToolType.ASTRONOMY -> PlaceholderAstronomyView()
                }
            }
        }

        if (!model.isMaximized) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .align(Alignment.BottomEnd)
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                onResizeMove(dragAmount.x, dragAmount.y)
                            },
                            onDragEnd = { onResizeEnd() }
                        )
                    },
                contentAlignment = Alignment.BottomEnd
            ) {
                Icon(
                    imageVector = Icons.Default.SouthEast,
                    contentDescription = "サイズ変更",
                    tint = Color(0xFF71717A),
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

@Composable
fun PlaceholderCalculatorView() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF09090B), RoundedCornerShape(6.dp))
                .padding(8.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Text("0", color = Color.White, fontSize = 20.sp, fontFamily = FontFamily.Monospace)
        }
        Text(
            text = "電卓ツール (仮コンテンツ)",
            color = Color(0xFFA1A1AA),
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
fun PlaceholderMemoView() {
    Column(modifier = Modifier.fillMaxSize()) {
        Text("クイックメモ (仮コンテンツ)", color = Color(0xFFFBBF24), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF09090B), RoundedCornerShape(6.dp))
                .padding(8.dp)
        ) {
            Text(
                "他アプリの上に表示されるメモ帳ウィンドウです。タイトルバーで移動、右下でサイズ変更が可能です。",
                color = Color(0xFFD4D4D8),
                fontSize = 11.sp,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun PlaceholderClockView() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("12:30:45", color = Color(0xFF67E8F9), fontSize = 26.sp, fontFamily = FontFamily.Monospace)
        Text("JST (東京, UTC+9)", color = Color(0xFFA1A1AA), fontSize = 10.sp)
    }
}

@Composable
fun PlaceholderTimerView() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("03:00", color = Color(0xFFFB7185), fontSize = 24.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Text("スタート", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun PlaceholderWeatherView() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("東京", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("晴れ", color = Color(0xFFA1A1AA), fontSize = 11.sp)
            }
            Text("21°C", color = Color(0xFF34D399), fontSize = 22.sp, fontWeight = FontWeight.Light)
        }
        Text("湿度: 45% • 降水確率: 10%", color = Color(0xFF71717A), fontSize = 10.sp)
    }
}

@Composable
fun PlaceholderAstronomyView() {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Nightlight, contentDescription = null, tint = Color(0xFFC084FC), modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("月齢 14.2 (待宵月)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text("二十四節気: 霜降 • 次の節気: 立冬", color = Color(0xFF94A3B8), fontSize = 10.sp)
    }
}