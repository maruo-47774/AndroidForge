package com.slidedock.app.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.util.DisplayMetrics
import android.view.*
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.*
import androidx.savedstate.*
import com.slidedock.app.model.DockPreferences
import com.slidedock.app.model.FloatingWindowModel
import com.slidedock.app.model.ToolType

/**
 * Android WindowManager を使用した複数のフローティングウィンドウ独立管理クラス
 */
class FloatingWindowManager(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val viewModelStoreOwner: ViewModelStoreOwner,
    private val savedStateRegistryOwner: SavedStateRegistryOwner
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val activeWindows = mutableMapOf<String, WindowViewHolder>()

    data class WindowViewHolder(
        val model: FloatingWindowModel,
        val rootView: FrameLayout,
        val layoutParams: WindowManager.LayoutParams
    )

    private fun getScreenWidth(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.widthPixels
    }

    private fun getScreenHeight(): Int {
        val display = windowManager.defaultDisplay
        val metrics = DisplayMetrics()
        display.getRealMetrics(metrics)
        return metrics.heightPixels
    }

    private fun dpToPx(dp: Int): Int {
        val density = context.resources.displayMetrics.density
        return (dp * density).toInt()
    }

    fun openToolWindow(toolType: ToolType) {
        val existing = activeWindows.values.find { it.model.toolType == toolType }
        if (existing != null) {
            if (existing.model.isMinimized) {
                restoreWindow(existing.model.id)
            } else {
                bringToFront(existing.model.id)
            }
            return
        }

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()
        val defaultW = Math.min(screenW - 40, dpToPx(toolType.defaultWidthDp))
        val defaultH = Math.min(screenH - 80, dpToPx(toolType.defaultHeightDp))

        val offset = (activeWindows.size % 5) * dpToPx(30)
        val initialX = Math.max(20, Math.min(screenW - defaultW - 20, dpToPx(40) + offset))
        val initialY = Math.max(40, Math.min(screenH - defaultH - 40, dpToPx(60) + offset))

        val model = FloatingWindowModel(
            id = "win_${toolType.name}_${System.currentTimeMillis()}",
            toolType = toolType,
            x = initialX,
            y = initialY,
            width = defaultW,
            height = defaultH
        )

        createAndAddWindow(model)
        saveState()
    }

    fun restoreSavedWindows() {
        val saved = DockPreferences.getWindows(context)
        for (model in saved) {
            if (!model.isMinimized) {
                createAndAddWindow(model)
            }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun createAndAddWindow(model: FloatingWindowModel) {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            model.width,
            model.height,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = model.x
            y = model.y
        }

        val rootView = FrameLayout(context).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowManager.lifecycleOwner)
            setViewTreeViewModelStoreOwner(this@FloatingWindowManager.viewModelStoreOwner)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowManager.savedStateRegistryOwner)
        }

        val composeView = ComposeView(context).apply {
            setViewTreeLifecycleOwner(this@FloatingWindowManager.lifecycleOwner)
            setViewTreeViewModelStoreOwner(this@FloatingWindowManager.viewModelStoreOwner)
            setViewTreeSavedStateRegistryOwner(this@FloatingWindowManager.savedStateRegistryOwner)
            setContent {
                FloatingWindowView(
                    model = model,
                    onMinimize = { minimizeWindow(model.id) },
                    onToggleMaximize = { toggleMaximizeWindow(model.id) },
                    onClose = { closeWindow(model.id) },
                    onDragStart = { bringToFront(model.id) },
                    onDragMove = { deltaX, deltaY ->
                        moveWindow(model.id, deltaX.toInt(), deltaY.toInt())
                    },
                    onDragEnd = { saveState() },
                    onResizeMove = { deltaW, deltaH ->
                        resizeWindow(model.id, deltaW.toInt(), deltaH.toInt())
                    },
                    onResizeEnd = { saveState() }
                )
            }
        }

        rootView.addView(composeView)

        rootView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                bringToFront(model.id)
            }
            false
        }

        try {
            windowManager.addView(rootView, params)
            activeWindows[model.id] = WindowViewHolder(model, rootView, params)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun moveWindow(id: String, deltaX: Int, deltaY: Int) {
        val holder = activeWindows[id] ?: return
        if (holder.model.isMaximized) return

        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        var newX = holder.layoutParams.x + deltaX
        var newY = holder.layoutParams.y + deltaY

        val minVisible = dpToPx(60)
        newX = Math.max(-holder.layoutParams.width + minVisible, Math.min(screenW - minVisible, newX))
        newY = Math.max(0, Math.min(screenH - dpToPx(40), newY))

        holder.layoutParams.x = newX
        holder.layoutParams.y = newY
        holder.model.x = newX
        holder.model.y = newY

        windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
    }

    fun resizeWindow(id: String, deltaW: Int, deltaH: Int) {
        val holder = activeWindows[id] ?: return
        if (holder.model.isMaximized) return

        val minW = dpToPx(200)
        val minH = dpToPx(150)
        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        var newW = holder.layoutParams.width + deltaW
        var newH = holder.layoutParams.height + deltaH

        newW = Math.max(minW, Math.min(screenW - holder.layoutParams.x, newW))
        newH = Math.max(minH, Math.min(screenH - holder.layoutParams.y, newH))

        holder.layoutParams.width = newW
        holder.layoutParams.height = newH
        holder.model.width = newW
        holder.model.height = newH

        windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
    }

    fun toggleMaximizeWindow(id: String) {
        val holder = activeWindows[id] ?: return
        val screenW = getScreenWidth()
        val screenH = getScreenHeight()

        if (holder.model.isMaximized) {
            holder.model.isMaximized = false
            holder.layoutParams.x = holder.model.prevX
            holder.layoutParams.y = holder.model.prevY
            holder.layoutParams.width = holder.model.prevWidth
            holder.layoutParams.height = holder.model.prevHeight
        } else {
            holder.model.isMaximized = true
            holder.model.prevX = holder.layoutParams.x
            holder.model.prevY = holder.layoutParams.y
            holder.model.prevWidth = holder.layoutParams.width
            holder.model.prevHeight = holder.layoutParams.height

            holder.layoutParams.x = dpToPx(8)
            holder.layoutParams.y = dpToPx(8)
            holder.layoutParams.width = screenW - dpToPx(16)
            holder.layoutParams.height = screenH - dpToPx(16)
        }

        windowManager.updateViewLayout(holder.rootView, holder.layoutParams)
        saveState()
    }

    fun minimizeWindow(id: String) {
        val holder = activeWindows[id] ?: return
        holder.model.isMinimized = true
        try {
            windowManager.removeView(holder.rootView)
        } catch (e: Exception) {
            // ignore
        }
        activeWindows.remove(id)
        saveState()
    }

    fun restoreWindow(id: String) {
        val saved = DockPreferences.getWindows(context)
        val model = saved.find { it.id == id } ?: return
        model.isMinimized = false
        createAndAddWindow(model)
        saveState()
    }

    fun closeWindow(id: String) {
        val holder = activeWindows.remove(id) ?: return
        try {
            windowManager.removeView(holder.rootView)
        } catch (e: Exception) {
            // ignore
        }
        saveState()
    }

    fun bringToFront(id: String) {
        val holder = activeWindows[id] ?: return
        try {
            windowManager.removeView(holder.rootView)
            windowManager.addView(holder.rootView, holder.layoutParams)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun getActiveWindowsCount(): Int = activeWindows.size

    private fun saveState() {
        val list = activeWindows.values.map { it.model }
        DockPreferences.saveWindows(context, list)
    }

    fun destroy() {
        for (holder in activeWindows.values) {
            try {
                windowManager.removeView(holder.rootView)
            } catch (e: Exception) {
                // ignore
            }
        }
        activeWindows.clear()
    }
}